﻿using SQLite;
using SQLiteNetExtensions.Attributes;
using System.Collections.Generic;

namespace INM.Models
{
	[Table("User")]
	public class User
	{
		[PrimaryKey, AutoIncrement]
		public int ID { get; set; }

		public string Username { get; set; }

		public string Email { get; set; }

		public string FirstName { get; set; }

		public string LastName { get; set; }

		public string PhoneNumber { get; set; }
		
		public string Password { get; set; }

		[ManyToMany(typeof(UserUser))]
		public List<User> Contacts { get; set; }

		[OneToMany]
		public List<Group> Groups { get; set; }

		[OneToMany]
		public List<AudioRecord> Recordings { get; set; }

		public override string ToString()
		{
			return $"ID={ID}\nUser name={Username}\nEmail={Email}\n" +
				$"Full name={FirstName} {LastName}\nPhone={PhoneNumber}";
		}
	}
}
